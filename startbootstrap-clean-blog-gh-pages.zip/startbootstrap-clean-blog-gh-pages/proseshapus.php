<?php 
include 'koneksi.php';
$id=$_GET['id'];

mysqli_query($dbconnect,"DELETE FROM `tb_pegawai1` WHERE id = '$id'");

header('location:contact.php');
 ?>
