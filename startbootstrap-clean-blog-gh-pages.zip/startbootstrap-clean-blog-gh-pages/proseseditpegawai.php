<?php 
include 'koneksi.php';

$id = $_POST['id'];
$nama= $_POST['nama'];
$alamat= $_POST['alamat'];
$kelamin= $_POST['kelamin'];
$nohp= $_POST['nohp'];
$agama= $_POST['agama'];

mysqli_query($dbconnect, "UPDATE `tb_pegawai1` SET `id`='$id',`nama`='$nama',`alamat`='$alamat',`kelamin`='$kelamin',`nohp`='$nohp',`agama`='$agama' WHERE `id`='$id'");

header('location:contact.php');

 ?>





