-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2022 at 10:23 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kantor`
--

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `NIP` int(20) NOT NULL,
  `NAMA_PEGAWAI` varchar(100) NOT NULL,
  `JABATAN` varchar(50) NOT NULL,
  `TEMPAT/TGL_LAHIR` varchar(50) NOT NULL,
  `AGAMA` varchar(20) NOT NULL,
  `NO_HP` int(20) NOT NULL,
  `NO_REKENING` int(30) NOT NULL,
  `ALAMAT` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`NIP`, `NAMA_PEGAWAI`, `JABATAN`, `TEMPAT/TGL_LAHIR`, `AGAMA`, `NO_HP`, `NO_REKENING`, `ALAMAT`) VALUES
(5678, 'esrdfh', 'fgfcgv', 'yftf', 'budha', 345678, 45678, ''),
(23456789, ' mvtfydrxfhgjvbk', ',mknjhgf', 'rtfyguhi', 'islam', 23456789, 3456789, 'sfxcghv3456ydcgvhgu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`NIP`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `NIP` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23456790;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
