<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Kantor Jaya Makmur</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <!-- Navigation-->
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
  </head>
  <body>
    
<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="index.html">Kantor JM</a>
  <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
  <div class="navbar-nav">
    <div class="nav-item text-nowrap">
      <a class="nav-link px-3" href="register.php">Sign out</a>
    </div>
  </div>
</header>


<div class="container-fluid">
  <div class="row">
    

    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.html">
              <span data-feather="home"></span>
              Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">
              <span data-feather="file"></span>
              Data Pegawai
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.html">
              <span data-feather="shopping-cart"></span>
              About
            </a>
          
        </ul>


      </div>
    </nav>


    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"> 
        <h1 class="h2">Input Data Pegawai</h1>
        </div>

        <section>
         <form action="prosesinputpegawai.php" method="POST">
          <div class="mb-3">
            <label for= "nama" class="form-label">Nama</label>
            <input name="nama" type="text" id="nama"class="form-control" autocomplete="off" required  placeholder="Masukan nama anda">
          </div>

          <div  class="mb-3">
            <label for= "alamat" class="form-label">Alamat</label>
            <input name="alamat" type="text" id="alamat" class="form-control" autocomplete="off" required  placeholder="Masukan alamat anda">
          </div>

          <div  class="mb-3">
            <label for= "kelamin" class="form-label" id="kelamin" autocomplete="off">Jenis Kelamin</label>
          <select class="form-select" name="kelamin">
            <option selected>Pilih Jenis Kelamin</option>
            <option value="laki-laki">Laki-Laki</option>
            <option value="perempuan">Perempuan</option>
          </select>
        </div>

        <div class="mb-3">
            <label for= "nohp" class="form-label" id="nohp" autocomplete="off">Nomor Hp</label>
            <input name="nohp" type="number" class="form-control" required  placeholder="Masukkan no hp anda">
          </div>

          <div class="mb-3">
            <label for= "agama" class="form-label" id="agama" autocomplete="off">Agama</label>
          <select class="form-select" name="agama">
            <option selected>Pilih Jenis Agama</option>
            <option value="islam">Islam</option>
            <option value="kristen">Kristen</option>
            <option value="katolik">Katolik</option>
            <option value="budha">Budha</option>
            <option value="hindu">Hindu</option>
          </select>
        </div>
          
          <button type="submit" name="inputdata" class="btn btn-primary" onclick="">Input Data</button>
        </form>
        </section>
       
    
    </main>
  </div>
</div>
    
    <script src="../assets/js/bootstrap.bundle.min.js" type="text/javascript"></script>

      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
        
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
