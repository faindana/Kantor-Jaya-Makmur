<?php 

$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_kantor";

$dbconnect = new mysqli ("$host","$user","$pass","$db");

?>